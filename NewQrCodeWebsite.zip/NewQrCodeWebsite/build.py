#!/usr/bin/env python3
"""Builds one static page per tool (e.g. /QrGenerator/index.html) plus the home page.

Sources: src/pages/*.html (page bodies), src/partials/ (header/footer) and js/*.js (per-tool scripts).
Run:  python3 build.py
"""
import os, re, html

ROOT = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(ROOT, 'src')
SITE = 'https://mydevstools.com'
CSS_V, JS_V = 14, 14

LIBS = {
    'qr': '<script src="https://cdn.jsdelivr.net/npm/qr-code-styling@1.8.4/lib/qr-code-styling.js"></script>',
    'barcode': '<script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.6/dist/JsBarcode.all.min.js"></script>',
    'diff': '<script src="https://cdn.jsdelivr.net/npm/diff@5.2.0/dist/diff.min.js"></script>',
}

# slug, nav label (or None), title, description, keywords, body file, js file, libs, short card text, icon
TOOLS = [
    ('QrGenerator', 'QRGenerator', 'Free QR Code Generator with Logo — Custom QR Codes (PNG/SVG)',
     'Create free custom QR codes for links, text, WiFi, email, phone, SMS and contact cards. Add your logo, pick colors and download PNG, SVG or JPG.',
     'QR code generator, free QR code, custom QR code with logo, WiFi QR code', 'qr', 'qr', ['qr'],
     'Custom QR codes for links, WiFi, contacts and more, with your logo.', '▦'),
    ('JsonParser', 'JsonParser', 'JSON Parser, Formatter & Validator Online',
     'Free online JSON parser, formatter and validator. Paste JSON to validate, pretty-print and find errors by line and column.',
     'JSON parser, JSON formatter, JSON validator, JSON beautifier', 'json', 'json', [],
     'Validate, format and beautify JSON with exact error locations.', '{ }'),
    ('JsonDiff', 'JsonDiff', 'JSON Diff — Compare Two JSON Documents Online',
     'Free JSON diff tool. Compare two JSON documents and see added, removed and changed values highlighted.',
     'JSON diff, JSON compare, compare JSON online', 'jsondiff', 'jsondiff', ['diff'],
     'Compare two JSON documents and highlight the differences.', '±'),
    ('RgbToHex', 'RGB-to-Hex', 'RGB to HEX Converter — HEX to RGB & HSL Color Converter',
     'Free RGB to HEX and HEX to RGB color converter with sliders, color picker and HSL output.',
     'RGB to HEX, HEX to RGB, color converter, RGB color picker', 'rgb', 'rgb', [],
     'Convert between RGB, HEX and HSL with a live color picker.', '🎨'),
    ('Base64', 'Base64', 'Base64 to Image & Image to Base64 Converter',
     'Free Base64 image converter. Decode Base64 strings or data URIs to images, or encode images to Base64.',
     'Base64 to image, image to Base64, Base64 decoder, Base64 encoder', 'base64', 'base64', [],
     'Decode Base64 to an image or encode an image to Base64.', '🖼'),
    ('UrlEncoderDecoder', 'URL', 'URL Encoder / Decoder — Percent Encoding Online',
     'Free URL encoder and decoder. Percent-encode or decode text and full URLs instantly in your browser.',
     'URL encoder, URL decoder, percent encoding, URL encode decode online', 'url', 'url', [],
     'Encode or decode URLs and query strings (percent-encoding).', '🔗'),
    ('TextCompare', None, 'Text Compare — Online Text Diff Checker',
     'Free text compare tool. Paste two versions of text and see what was added or removed.',
     'text compare, text diff checker, compare two texts', 'tool-diff', 'textcompare', ['diff'],
     'Compare two versions of text and highlight what was added or removed.', '⇄'),
    ('BarcodeGenerator', None, 'Barcode Generator — Code 128, EAN-13, UPC, Code 39',
     'Free barcode generator. Create Code 128, EAN-13, UPC and Code 39 barcodes and download PNG or SVG.',
     'barcode generator, EAN-13, UPC, Code 128, Code 39', 'tool-barcode', 'barcode', ['barcode'],
     'Create Code 128, EAN-13, UPC and Code 39 barcodes.', '▥'),
    ('WordCounter', None, 'Word Counter — Count Words, Characters & Reading Time',
     'Free word counter. Count words, characters, sentences, paragraphs and estimate reading time.',
     'word counter, character counter, reading time', 'tool-words', 'wordcounter', [],
     'Count words, characters, sentences, paragraphs and reading time.', '📝'),
    ('UpiQrGenerator', None, 'UPI QR Code Generator — Payment QR with Amount',
     'Free UPI QR code generator. Create a payment QR with your VPA, name and amount.',
     'UPI QR code generator, UPI payment QR', 'tool-upi', 'upi', ['qr'],
     'Generate a UPI payment QR code with your VPA, name and amount.', '💸'),
    ('JwtDecoder', None, 'JWT Decoder — Decode JSON Web Tokens Online',
     'Free JWT decoder. Decode a JSON Web Token header and payload instantly in your browser.',
     'JWT decoder, decode JWT, JSON web token', 'tool-jwt', 'jwt', [],
     "Decode a JSON Web Token's header and payload instantly.", '🔑'),
    ('RegexTester', None, 'Regex Tester — Test Regular Expressions Online',
     'Free regex tester with live match highlighting and capture groups.',
     'regex tester, regular expression tester', 'tool-regex', 'regex', [],
     'Test regular expressions with live match highlighting.', '🔍'),
    ('UuidGenerator', None, 'UUID Generator — Random v4 UUIDs Online',
     'Free UUID generator. Create one or many random version 4 UUIDs.',
     'UUID generator, GUID generator, uuid v4', 'tool-uuid', 'uuid', [],
     'Generate one or many random version 4 UUIDs.', '🆔'),
    ('HashGenerator', None, 'Hash Generator — SHA-1, SHA-256, SHA-384, SHA-512',
     'Free hash generator. Compute SHA-1, SHA-256, SHA-384 and SHA-512 hashes of text.',
     'hash generator, SHA-256, SHA-512, SHA-1', 'tool-hash', 'hash', [],
     'Compute SHA-1, SHA-256, SHA-384 and SHA-512 hashes of text.', '#️⃣'),
    ('XmlFormatter', None, 'XML Formatter — Validate, Beautify & Minify XML',
     'Free XML formatter. Validate, beautify or minify XML documents.',
     'XML formatter, XML beautifier, XML validator', 'tool-xml', 'xml', [],
     'Validate, beautify or minify XML documents.', '</>'),
]

NAV = [(t[0], t[1]) for t in TOOLS if t[1]]


# When opened straight from disk (file://) folder links don't resolve to index.html, so add it.
FILE_FIX = '<script>if(location.protocol==="file:"){document.querySelectorAll("a[href]").forEach(function(a){var h=a.getAttribute("href");if(/\\/($|#)/.test(h)){a.setAttribute("href",h.replace(/\\/(#|$)/,"/index.html$1"))}})}</script>'


def read(*p):
    with open(os.path.join(*p), encoding='utf-8') as f:
        return f.read()


def write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(text)


HEADER = read(SRC, 'partials', 'header.html')
FOOTER = read(SRC, 'partials', 'footer.html')


def nav_html(active, P):
    links = ''
    for slug, label in NAV:
        cls = 'nav-tool active' if slug == active else 'nav-tool'
        links += '<a href="%s%s/" class="%s">%s</a>' % (P, slug, cls, label)
    cls = 'nav-tool active' if active == 'home' else 'nav-tool'
    contact = 'nav-tool active' if active == 'Contact' else 'nav-tool'
    faq = 'nav-tool active' if active == 'FAQ' else 'nav-tool'
    return links + '<a href="%s#tools" class="%s">More Tools</a><a href="%sContact/" class="%s">Contact</a><a href="%sFAQ/" class="%s">FAQ</a>' % (P, cls, P, contact, P, faq)


def page(slug, title, desc, keywords, body, js_files, libs):
    P = '../' if slug else './'
    url = f'{SITE}/{slug}' if slug else f'{SITE}/'
    t = html.escape(title)
    d = html.escape(desc)
    scripts = ''.join(LIBS[l] + '\n' for l in libs)
    scripts += '<script src="%sjs/common.js?v=%d"></script>\n' % (P, JS_V)
    for j in js_files:
        scripts += '<script src="%sjs/%s.js?v=%d"></script>\n' % (P, j, JS_V)
    return f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>{t} | myDevTools</title>
<meta name="description" content="{d}" />
<meta name="keywords" content="{html.escape(keywords)}" />
<meta name="robots" content="index, follow" />
<link rel="canonical" href="{url}" />
<meta property="og:type" content="website" />
<meta property="og:site_name" content="myDevTools" />
<meta property="og:title" content="{t}" />
<meta property="og:description" content="{d}" />
<meta property="og:url" content="{url}" />
<meta name="twitter:card" content="summary" />
<meta name="twitter:title" content="{t}" />
<meta name="twitter:description" content="{d}" />
<script type="application/ld+json">
{{"@context":"https://schema.org","@type":"WebApplication","name":"{t}","url":"{url}","applicationCategory":"DeveloperApplication","operatingSystem":"Any","offers":{{"@type":"Offer","price":"0","priceCurrency":"USD"}},"description":"{d}"}}
</script>
<link rel="icon" href="{P}assets/favicon.svg" type="image/svg+xml" />
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="{P}css/style.css?v={CSS_V}" />
</head>
<body>
{HEADER.replace('{{NAV}}', nav_html(slug or 'home', P)).replace('{{P}}', P)}
{body}
{FOOTER.replace('{{P}}', P)}
{FILE_FIX}
{scripts}</body>
</html>
'''


def main():
    for slug, _nav, title, desc, kw, bodyf, jsf, libs, _card, _icon in TOOLS:
        body = read(SRC, 'pages', bodyf + '.html')
        write(os.path.join(ROOT, slug, 'index.html'), page(slug, title, desc, kw, body, [jsf], libs))

    write(os.path.join(ROOT, 'Contact', 'index.html'), page(
        'Contact', 'Contact Us', 'Contact myDevTools — questions, bug reports and tool suggestions. Email myDevsTools@gmail.com.',
        'contact myDevTools, support, feedback', read(SRC, 'pages', 'contact.html'), ['contact'], []))
    write(os.path.join(ROOT, 'FAQ', 'index.html'), page(
        'FAQ', 'FAQ — Frequently Asked Questions', 'Answers to common questions about myDevTools: privacy, pricing, QR codes, JSON, Base64 and more.',
        'myDevTools FAQ, QR code FAQ, developer tools help', read(SRC, 'pages', 'faq.html'), [], []))
    cards = []
    for slug, _n, title, _d, _k, _b, _j, _l, card, icon in TOOLS:
        names = {'QrGenerator': 'QR Code Generator', 'JsonParser': 'JSON Parser', 'JsonDiff': 'JSON Diff',
                 'RgbToHex': 'RGB to HEX', 'UrlEncoderDecoder': 'URL Encoder / Decoder', 'TextCompare': 'Text Compare',
                 'BarcodeGenerator': 'Barcode Generator', 'WordCounter': 'Word Counter',
                 'UpiQrGenerator': 'UPI QR Code Generator', 'JwtDecoder': 'JWT Decoder', 'RegexTester': 'Regex Tester',
                 'UuidGenerator': 'UUID Generator', 'HashGenerator': 'Hash Generator', 'XmlFormatter': 'XML Formatter',
                 'Base64': 'Base64 Image Converter'}
        cards.append(f'      <a href="{slug}/" class="tool-card"><div class="feature-icon">{icon}</div><h3>{names[slug]}</h3><p>{html.escape(card)}</p><span>Open Tool →</span></a>')
    home_body = read(SRC, 'pages', 'home.html').replace('{{CARDS}}', '\n'.join(cards))
    write(os.path.join(ROOT, 'index.html'), page(
        '', 'myDevTools — Free Online Developer Tools: QR Code Generator, JSON Parser, Base64 & More',
        'Free online developer tools: QR code generator, JSON parser & formatter, JSON diff, text compare, RGB to HEX, Base64, URL encoder/decoder and more. Fast, private, no sign-up.',
        'online developer tools, QR code generator, JSON parser, JSON diff, RGB to HEX, Base64, URL encoder decoder, free dev tools',
        home_body, [], []))

    urls = [f'{SITE}/'] + [f'{SITE}/{t[0]}' for t in TOOLS] + [f'{SITE}/Contact', f'{SITE}/FAQ']
    write(os.path.join(ROOT, 'sitemap.xml'),
          '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' +
          ''.join(f'  <url><loc>{u}</loc></url>\n' for u in urls) + '</urlset>\n')
    write(os.path.join(ROOT, 'robots.txt'), f'User-agent: *\nAllow: /\nSitemap: {SITE}/sitemap.xml\n')
    print('built', len(TOOLS) + 1, 'pages')


if __name__ == '__main__':
    main()
