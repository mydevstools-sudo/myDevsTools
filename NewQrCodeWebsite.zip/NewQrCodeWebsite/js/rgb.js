// ---- RGB to Hex ----
const rgbFields = ['R', 'G', 'B'].map((c) => ({
  num: document.getElementById(`rgb${c}`),
  range: document.getElementById(`rgb${c}Range`),
}));
const rgbPicker = document.getElementById('rgbPicker');
const hexInput = document.getElementById('hexInput');
const rgbString = document.getElementById('rgbString');
const hslString = document.getElementById('hslString');
const rgbSwatch = document.getElementById('rgbSwatch');
const rgbStatus = document.getElementById('rgbStatus');

const clamp255 = (n) => Math.min(255, Math.max(0, Math.round(Number(n) || 0)));
const toHex = (r, g, b) =>
  '#' + [r, g, b].map((v) => v.toString(16).padStart(2, '0')).join('').toUpperCase();

function rgbToHsl(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const l = (max + min) / 2;
  const d = max - min;
  let h = 0;
  let s = 0;
  if (d) {
    s = d / (1 - Math.abs(2 * l - 1));
    if (max === r) h = ((g - b) / d) % 6;
    else if (max === g) h = (b - r) / d + 2;
    else h = (r - g) / d + 4;
    h = Math.round(h * 60);
    if (h < 0) h += 360;
  }
  return `hsl(${h}, ${Math.round(s * 100)}%, ${Math.round(l * 100)}%)`;
}

function renderRgb(r, g, b, skip) {
  const hex = toHex(r, g, b);
  [r, g, b].forEach((v, i) => {
    if (skip !== 'rgb') rgbFields[i].num.value = v;
    rgbFields[i].range.value = v;
  });
  if (skip !== 'hex') hexInput.value = hex;
  rgbPicker.value = hex.toLowerCase();
  rgbString.value = `rgb(${r}, ${g}, ${b})`;
  hslString.value = rgbToHsl(r, g, b);
  rgbSwatch.style.background = hex;
}

function onRgbInput(source) {
  return () => {
    const [r, g, b] = rgbFields.map((f) => clamp255(f[source].value));
    renderRgb(r, g, b, source === 'num' ? 'rgb' : '');
    rgbStatus.textContent = '';
  };
}

rgbFields.forEach((f) => {
  f.num.addEventListener('input', onRgbInput('num'));
  f.num.addEventListener('blur', onRgbInput('range'));
  f.range.addEventListener('input', onRgbInput('range'));
});

rgbPicker.addEventListener('input', () => {
  const v = rgbPicker.value;
  renderRgb(parseInt(v.slice(1, 3), 16), parseInt(v.slice(3, 5), 16), parseInt(v.slice(5, 7), 16));
  rgbStatus.textContent = '';
});

hexInput.addEventListener('input', () => {
  let v = hexInput.value.trim().replace(/^#/, '');
  if (/^[0-9a-f]{3}$/i.test(v)) v = v.split('').map((c) => c + c).join('');
  if (/^[0-9a-f]{6}$/i.test(v)) {
    renderRgb(parseInt(v.slice(0, 2), 16), parseInt(v.slice(2, 4), 16), parseInt(v.slice(4, 6), 16), 'hex');
    rgbStatus.textContent = '';
  } else {
    rgbStatus.textContent = '✗ Enter a valid hex code, e.g. #6C5CE7';
    rgbStatus.className = 'json-status error';
  }
});

[['copyHex', hexInput], ['copyRgb', rgbString], ['copyHsl', hslString]].forEach(([id, input]) => {
  const btn = document.getElementById(id);
  btn.addEventListener('click', () => {
    navigator.clipboard.writeText(input.value).then(() => {
      btn.textContent = 'Copied!';
      setTimeout(() => { btn.textContent = 'Copy'; }, 1500);
    });
  });
});

renderRgb(108, 92, 231);

