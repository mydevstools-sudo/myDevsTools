// ---- Text Compare ----
const diffInputLeft = document.getElementById('diffInputLeft');
const diffInputRight = document.getElementById('diffInputRight');
const diffOutput = document.getElementById('diffOutput');
const diffCompareBtn = document.getElementById('diffCompareBtn');
const diffSampleLeftBtn = document.getElementById('diffSampleLeft');
const diffSampleRightBtn = document.getElementById('diffSampleRight');
const diffClearLeftBtn = document.getElementById('diffClearLeft');
const diffClearRightBtn = document.getElementById('diffClearRight');

const DIFF_SAMPLE_LEFT = `The quick brown fox jumps over the lazy dog.
This is the original version of the text.`;
const DIFF_SAMPLE_RIGHT = `The quick brown fox leaps over the lazy dog.
This is the updated version of the text.`;

function compareText() {
  const left = diffInputLeft.value;
  const right = diffInputRight.value;

  if (!left.trim() && !right.trim()) {
    diffOutput.textContent = 'Paste text on both sides and click "Compare Text" to see the differences.';
    return;
  }

  const parts = Diff.diffWordsWithSpace(left, right);
  diffOutput.textContent = '';
  parts.forEach((part) => {
    const el = document.createElement(part.added ? 'ins' : part.removed ? 'del' : 'span');
    el.textContent = part.value;
    diffOutput.appendChild(el);
  });
}

diffCompareBtn.addEventListener('click', compareText);

diffSampleLeftBtn.addEventListener('click', () => { diffInputLeft.value = DIFF_SAMPLE_LEFT; });
diffSampleRightBtn.addEventListener('click', () => { diffInputRight.value = DIFF_SAMPLE_RIGHT; });

diffClearLeftBtn.addEventListener('click', () => { diffInputLeft.value = ''; });
diffClearRightBtn.addEventListener('click', () => { diffInputRight.value = ''; });

