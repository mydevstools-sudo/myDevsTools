(function () {
  const $ = (id) => document.getElementById(id);
  const copyText = (text) => navigator.clipboard.writeText(text);
  const download = (href, name) => { const a = document.createElement('a'); a.href = href; a.download = name; a.click(); };
  // JWT
  const b64urlDecode = (s) => {
    s = s.replace(/-/g, '+').replace(/_/g, '/');
    while (s.length % 4) s += '=';
    return decodeURIComponent(Array.from(atob(s), (c) => '%' + c.charCodeAt(0).toString(16).padStart(2, '0')).join(''));
  };
  function decodeJwt() {
    const st = $('jwtStatus');
    const tok = $('jwtInput').value.trim();
    $('jwtHeader').textContent = ''; $('jwtPayload').textContent = '';
    if (!tok) { st.textContent = ''; st.className = 'json-status'; return; }
    try {
      const parts = tok.split('.');
      if (parts.length < 2) throw new Error('A JWT has three dot-separated parts.');
      $('jwtHeader').textContent = JSON.stringify(JSON.parse(b64urlDecode(parts[0])), null, 2);
      const payload = JSON.parse(b64urlDecode(parts[1]));
      $('jwtPayload').textContent = JSON.stringify(payload, null, 2);
      let msg = 'Token decoded.';
      if (typeof payload.exp === 'number') {
        msg += payload.exp * 1000 < Date.now() ? ' Expired ' : ' Expires ';
        msg += new Date(payload.exp * 1000).toLocaleString() + '.';
      }
      st.textContent = msg; st.className = 'json-status success';
    } catch (e) {
      st.textContent = 'Invalid JWT: ' + e.message; st.className = 'json-status error';
    }
  }
  $('jwtInput').addEventListener('input', decodeJwt);
  $('jwtSample').addEventListener('click', () => {
    $('jwtInput').value = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkphbmUgRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c';
    decodeJwt();
  });
  if (window.toolInit.jwt) window.toolInit.jwt();
})();
