(function () {
  const $ = (id) => document.getElementById(id);
  const copyText = (text) => navigator.clipboard.writeText(text);
  const download = (href, name) => { const a = document.createElement('a'); a.href = href; a.download = name; a.click(); };
  // UPI
  let upiQr = null;
  function drawUpi() {
    const vpa = $('upiVpa').value.trim();
    const st = $('upiStatus');
    if (!upiQr) {
      upiQr = new QRCodeStyling({ width: 260, height: 260, data: 'upi://pay', dotsOptions: { color: '#1a1a2e', type: 'rounded' } });
      upiQr.append($('upiQr'));
    }
    if (!/^[\w.\-]{2,}@[A-Za-z]{2,}$/.test(vpa)) {
      st.textContent = vpa ? 'Enter a valid UPI ID like name@bank.' : 'Enter a UPI ID to generate the QR code.';
      st.className = 'json-status error';
      return;
    }
    st.textContent = ''; st.className = 'json-status';
    const p = new URLSearchParams({ pa: vpa, cu: 'INR' });
    if ($('upiName').value.trim()) p.set('pn', $('upiName').value.trim());
    if ($('upiAmount').value) p.set('am', Number($('upiAmount').value).toFixed(2));
    if ($('upiNote').value.trim()) p.set('tn', $('upiNote').value.trim());
    upiQr.update({ data: 'upi://pay?' + p.toString().replace(/\+/g, '%20') });
  }
  ['upiVpa', 'upiName', 'upiAmount', 'upiNote'].forEach((id) => $(id).addEventListener('input', drawUpi));
  $('upiPng').addEventListener('click', () => upiQr && upiQr.download({ name: 'upi-qr', extension: 'png' }));
  window.toolInit.upi = drawUpi;
  if (window.toolInit.upi) window.toolInit.upi();
})();
