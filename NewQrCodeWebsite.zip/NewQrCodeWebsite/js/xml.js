(function () {
  const $ = (id) => document.getElementById(id);
  const copyText = (text) => navigator.clipboard.writeText(text);
  const download = (href, name) => { const a = document.createElement('a'); a.href = href; a.download = name; a.click(); };
  // XML
  function parseXml() {
    const src = $('xmlInput').value.trim();
    const st = $('xmlStatus');
    if (!src) { st.textContent = 'Paste some XML first.'; st.className = 'json-status error'; return null; }
    const doc = new DOMParser().parseFromString(src, 'application/xml');
    const err = doc.querySelector('parsererror');
    if (err) { st.textContent = 'Invalid XML: ' + err.textContent.split('\n')[0]; st.className = 'json-status error'; $('xmlOutput').textContent = ''; return null; }
    st.textContent = 'Valid XML.'; st.className = 'json-status success';
    return doc;
  }
  function serialize(node, depth, pretty) {
    const pad = pretty ? '  '.repeat(depth) : '';
    const nl = pretty ? '\n' : '';
    if (node.nodeType === 3) { const t = node.nodeValue.trim(); return t ? pad + esc(t) + nl : ''; }
    if (node.nodeType === 4) return pad + '<![CDATA[' + node.nodeValue + ']]>' + nl;
    if (node.nodeType === 8) return pad + '<!--' + node.nodeValue + '-->' + nl;
    if (node.nodeType !== 1) return '';
    let attrs = '';
    for (const a of node.attributes) attrs += ' ' + a.name + '="' + a.value.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;') + '"';
    const kids = Array.from(node.childNodes);
    if (!kids.length) return pad + '<' + node.nodeName + attrs + '/>' + nl;
    if (kids.length === 1 && kids[0].nodeType === 3) return pad + '<' + node.nodeName + attrs + '>' + esc(kids[0].nodeValue.trim()) + '</' + node.nodeName + '>' + nl;
    return pad + '<' + node.nodeName + attrs + '>' + nl + kids.map((k) => serialize(k, depth + 1, pretty)).join('') + pad + '</' + node.nodeName + '>' + nl;
  }
  function xmlOut(pretty) {
    const doc = parseXml();
    if (!doc) return;
    const decl = $('xmlInput').value.trim().match(/^<\?xml[^>]*\?>/);
    const body = Array.from(doc.childNodes).map((n) => serialize(n, 0, pretty)).join('');
    $('xmlOutput').textContent = ((decl ? decl[0] + (pretty ? '\n' : '') : '') + body).trim();
  }
  $('xmlFormat').addEventListener('click', () => xmlOut(true));
  $('xmlMinify').addEventListener('click', () => xmlOut(false));
  $('xmlCopy').addEventListener('click', () => copyText($('xmlOutput').textContent));
  $('xmlClear').addEventListener('click', () => { $('xmlInput').value = ''; $('xmlOutput').textContent = ''; $('xmlStatus').textContent = ''; });
  $('xmlSample').addEventListener('click', () => {
    $('xmlInput').value = '<?xml version="1.0"?><catalog><book id="1"><title>Dev Guide</title><price>9.99</price></book><book id="2"><title>QR Basics</title><price>4.50</price></book></catalog>';
    xmlOut(true);
  });
})();
