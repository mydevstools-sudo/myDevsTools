document.getElementById('year').textContent = new Date().getFullYear();

// ---- Page switching (QR Generator / JSON Parser / JSON Diff / Text Compare) ----
const pageQr = document.getElementById('page-qr');
const pageJson = document.getElementById('page-json');
const pageJsonDiff = document.getElementById('page-jsondiff');
const pageDiff = document.getElementById('page-diff');

function showPage(page) {
  pageQr.style.display = page === 'qr' ? '' : 'none';
  pageJson.style.display = page === 'json' ? '' : 'none';
  pageJsonDiff.style.display = page === 'jsondiff' ? '' : 'none';
  pageDiff.style.display = page === 'diff' ? '' : 'none';
  document.querySelectorAll('.main-nav a.nav-tool')
    .forEach((a) => a.classList.toggle('active', a.dataset.page === page));
}

document.querySelectorAll('[data-page]').forEach((link) => {
  link.addEventListener('click', (e) => {
    const page = link.dataset.page;
    const href = link.getAttribute('href');
    e.preventDefault();
    showPage(page);
    const target = href && href !== '#' ? document.querySelector(href) : null;
    if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
});

showPage('qr');

let currentType = 'url';
let logoDataUrl = null;

const qrCode = new QRCodeStyling({
  width: 260,
  height: 260,
  type: 'svg',
  data: 'https://example.com',
  margin: 8,
  qrOptions: { errorCorrectionLevel: 'Q' },
  dotsOptions: { color: '#1a1a2e', type: 'classy' },
  backgroundOptions: { color: '#ffffff' },
  cornersSquareOptions: { color: '#1a1a2e', type: 'extra-rounded' },
  cornersDotOptions: { color: '#1a1a2e' },
  imageOptions: { crossOrigin: 'anonymous', margin: 6, imageSize: 0.4 },
});

qrCode.append(document.getElementById('qrPreview'));

const heroQr = new QRCodeStyling({
  width: 220,
  height: 220,
  type: 'svg',
  data: 'https://example.com',
  margin: 6,
  qrOptions: { errorCorrectionLevel: 'Q' },
  dotsOptions: { color: '#1a1a2e', type: 'classy' },
  backgroundOptions: { color: '#ffffff' },
  cornersSquareOptions: { color: '#1a1a2e', type: 'extra-rounded' },
  cornersDotOptions: { color: '#1a1a2e' },
});
heroQr.append(document.getElementById('heroQrFrame'));

// ---- Type tabs ----
const typeTabs = document.querySelectorAll('.type-tab');
const typeForms = document.querySelectorAll('.type-form');

typeTabs.forEach((tab) => {
  tab.addEventListener('click', () => {
    typeTabs.forEach((t) => t.classList.remove('active'));
    tab.classList.add('active');
    currentType = tab.dataset.type;
    typeForms.forEach((f) => f.classList.toggle('active', f.dataset.form === currentType));
    updateQrData();
  });
});

// ---- Data builders ----
function escapeVCard(str) {
  return (str || '').replace(/([,;])/g, '\\$1');
}

function buildData() {
  switch (currentType) {
    case 'url': {
      let val = document.getElementById('url-input').value.trim() || 'https://example.com';
      if (!/^https?:\/\//i.test(val)) val = 'https://' + val;
      return val;
    }
    case 'text':
      return document.getElementById('text-input').value || ' ';
    case 'email': {
      const addr = document.getElementById('email-address').value.trim();
      const subject = encodeURIComponent(document.getElementById('email-subject').value.trim());
      const body = encodeURIComponent(document.getElementById('email-body').value.trim());
      let str = `mailto:${addr}`;
      const params = [];
      if (subject) params.push(`subject=${subject}`);
      if (body) params.push(`body=${body}`);
      if (params.length) str += `?${params.join('&')}`;
      return str;
    }
    case 'phone': {
      const num = document.getElementById('phone-input').value.trim();
      return `tel:${num}`;
    }
    case 'sms': {
      const num = document.getElementById('sms-number').value.trim();
      const msg = encodeURIComponent(document.getElementById('sms-message').value.trim());
      return msg ? `smsto:${num}:${msg}` : `smsto:${num}:`;
    }
    case 'wifi': {
      const ssid = escapeVCard(document.getElementById('wifi-ssid').value.trim());
      const pass = escapeVCard(document.getElementById('wifi-password').value.trim());
      const enc = document.getElementById('wifi-encryption').value;
      const hidden = document.getElementById('wifi-hidden').checked ? 'true' : 'false';
      const passSegment = enc === 'nopass' ? '' : `P:${pass};`;
      return `WIFI:T:${enc};S:${ssid};${passSegment}H:${hidden};;`;
    }
    case 'vcard': {
      const first = document.getElementById('vcard-first').value.trim();
      const last = document.getElementById('vcard-last').value.trim();
      const phone = document.getElementById('vcard-phone').value.trim();
      const email = document.getElementById('vcard-email').value.trim();
      const company = document.getElementById('vcard-company').value.trim();
      const website = document.getElementById('vcard-website').value.trim();
      return [
        'BEGIN:VCARD',
        'VERSION:3.0',
        `N:${escapeVCard(last)};${escapeVCard(first)};;;`,
        `FN:${escapeVCard(first + ' ' + last)}`,
        company ? `ORG:${escapeVCard(company)}` : '',
        phone ? `TEL;TYPE=CELL:${phone}` : '',
        email ? `EMAIL:${email}` : '',
        website ? `URL:${website}` : '',
        'END:VCARD',
      ].filter(Boolean).join('\n');
    }
    default:
      return ' ';
  }
}

// ---- Update QR ----
let updateTimer = null;
function updateQrData() {
  clearTimeout(updateTimer);
  updateTimer = setTimeout(() => {
    const data = buildData() || ' ';
    qrCode.update({ data });
  }, 150);
}

function updateQrStyle() {
  const fg = document.getElementById('fgColor').value;
  const bg = document.getElementById('bgColor').value;
  const dotStyle = document.getElementById('dotStyle').value;
  const cornerStyle = document.getElementById('cornerStyle').value;

  qrCode.update({
    dotsOptions: { color: fg, type: dotStyle },
    backgroundOptions: { color: bg },
    cornersSquareOptions: { color: fg, type: cornerStyle },
    cornersDotOptions: { color: fg },
    image: logoDataUrl || undefined,
  });
}

// ---- Listen to all inputs ----
document.querySelectorAll('.type-form input, .type-form textarea, .type-form select')
  .forEach((el) => el.addEventListener('input', updateQrData));

['fgColor', 'bgColor', 'dotStyle', 'cornerStyle'].forEach((id) => {
  document.getElementById(id).addEventListener('input', updateQrStyle);
  document.getElementById(id).addEventListener('change', updateQrStyle);
});

// ---- Logo upload ----
document.getElementById('logoUpload').addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (ev) => {
    logoDataUrl = ev.target.result;
    updateQrStyle();
  };
  reader.readAsDataURL(file);
});

document.getElementById('removeLogo').addEventListener('click', () => {
  logoDataUrl = null;
  document.getElementById('logoUpload').value = '';
  updateQrStyle();
});

// ---- Downloads ----
document.getElementById('downloadPng').addEventListener('click', () => {
  qrCode.download({ name: 'qr-code', extension: 'png' });
});
document.getElementById('downloadSvg').addEventListener('click', () => {
  qrCode.download({ name: 'qr-code', extension: 'svg' });
});
document.getElementById('downloadJpg').addEventListener('click', () => {
  qrCode.download({ name: 'qr-code', extension: 'jpeg' });
});

// ---- Init ----
updateQrData();

// ---- JSON Parser ----
const jsonInput = document.getElementById('jsonInput');
const jsonOutput = document.getElementById('jsonOutput');
const jsonStatus = document.getElementById('jsonStatus');
const jsonSampleBtn = document.getElementById('jsonSample');
const jsonClearBtn = document.getElementById('jsonClear');
const jsonCopyBtn = document.getElementById('jsonCopy');
const jsonValidateBtn = document.getElementById('jsonValidate');

const JSON_SAMPLE = `{
  "name": "Jane Doe",
  "age": 29,
  "isActive": true,
  "skills": ["JavaScript", "Python", "SQL"],
  "address": {
    "city": "San Francisco",
    "zip": "94107"
  }
}`;

function getLineColumn(text, pos) {
  const upToPos = text.slice(0, pos);
  const lines = upToPos.split('\n');
  return { line: lines.length, column: lines[lines.length - 1].length + 1 };
}

function setJsonStatus(message, type) {
  jsonStatus.textContent = message;
  jsonStatus.className = `json-status${type ? ' ' + type : ''}`;
}

function validateJson() {
  const text = jsonInput.value;
  if (!text.trim()) {
    setJsonStatus('', '');
    jsonOutput.textContent = '';
    return;
  }
  try {
    const parsed = JSON.parse(text);
    jsonOutput.textContent = JSON.stringify(parsed, null, 2);
    setJsonStatus('✓ Valid JSON', 'success');
  } catch (e) {
    let detail = e.message;
    const match = detail.match(/position (\d+)/);
    if (match) {
      const { line, column } = getLineColumn(text, parseInt(match[1], 10));
      detail = `${e.message} (line ${line}, column ${column})`;
    }
    jsonOutput.textContent = '';
    setJsonStatus(`✗ Invalid JSON — ${detail}`, 'error');
  }
}

let jsonTimer = null;
jsonInput.addEventListener('input', () => {
  clearTimeout(jsonTimer);
  jsonTimer = setTimeout(validateJson, 250);
});

jsonValidateBtn.addEventListener('click', validateJson);

jsonSampleBtn.addEventListener('click', () => {
  jsonInput.value = JSON_SAMPLE;
  validateJson();
});

jsonClearBtn.addEventListener('click', () => {
  jsonInput.value = '';
  jsonOutput.textContent = '';
  setJsonStatus('', '');
  jsonInput.focus();
});

jsonCopyBtn.addEventListener('click', () => {
  if (!jsonOutput.textContent) return;
  navigator.clipboard.writeText(jsonOutput.textContent).then(() => {
    const original = jsonCopyBtn.textContent;
    jsonCopyBtn.textContent = 'Copied!';
    setTimeout(() => { jsonCopyBtn.textContent = original; }, 1500);
  });
});

// ---- Text Compare ----
const diffInputLeft = document.getElementById('diffInputLeft');
const diffInputRight = document.getElementById('diffInputRight');
const diffOutput = document.getElementById('diffOutput');
const diffCompareBtn = document.getElementById('diffCompareBtn');
const diffSampleLeftBtn = document.getElementById('diffSampleLeft');
const diffSampleRightBtn = document.getElementById('diffSampleRight');
const diffClearLeftBtn = document.getElementById('diffClearLeft');
const diffClearRightBtn = document.getElementById('diffClearRight');

const DIFF_SAMPLE_LEFT = `The quick brown fox jumps over the lazy dog.
This is the original version of the text.`;
const DIFF_SAMPLE_RIGHT = `The quick brown fox leaps over the lazy dog.
This is the updated version of the text.`;

function compareText() {
  const left = diffInputLeft.value;
  const right = diffInputRight.value;

  if (!left.trim() && !right.trim()) {
    diffOutput.textContent = 'Paste text on both sides and click "Compare Text" to see the differences.';
    return;
  }

  const parts = Diff.diffWordsWithSpace(left, right);
  diffOutput.textContent = '';
  parts.forEach((part) => {
    const el = document.createElement(part.added ? 'ins' : part.removed ? 'del' : 'span');
    el.textContent = part.value;
    diffOutput.appendChild(el);
  });
}

diffCompareBtn.addEventListener('click', compareText);

diffSampleLeftBtn.addEventListener('click', () => { diffInputLeft.value = DIFF_SAMPLE_LEFT; });
diffSampleRightBtn.addEventListener('click', () => { diffInputRight.value = DIFF_SAMPLE_RIGHT; });

diffClearLeftBtn.addEventListener('click', () => { diffInputLeft.value = ''; });
diffClearRightBtn.addEventListener('click', () => { diffInputRight.value = ''; });

// ---- JSON Diff ----
const jsonDiffInputLeft = document.getElementById('jsonDiffInputLeft');
const jsonDiffInputRight = document.getElementById('jsonDiffInputRight');
const jsonDiffOutput = document.getElementById('jsonDiffOutput');
const jsonDiffStatus = document.getElementById('jsonDiffStatus');
const jsonDiffCompareBtn = document.getElementById('jsonDiffCompareBtn');
const jsonDiffSampleLeftBtn = document.getElementById('jsonDiffSampleLeft');
const jsonDiffSampleRightBtn = document.getElementById('jsonDiffSampleRight');
const jsonDiffClearLeftBtn = document.getElementById('jsonDiffClearLeft');
const jsonDiffClearRightBtn = document.getElementById('jsonDiffClearRight');

const JSON_DIFF_SAMPLE_LEFT = `{
  "name": "Jane Doe",
  "age": 29,
  "city": "San Francisco",
  "skills": ["JavaScript", "Python"]
}`;
const JSON_DIFF_SAMPLE_RIGHT = `{
  "name": "Jane Doe",
  "age": 30,
  "country": "USA",
  "skills": ["JavaScript", "Python", "Go"]
}`;

function setJsonDiffStatus(message, type) {
  jsonDiffStatus.textContent = message;
  jsonDiffStatus.className = `json-status${type ? ' ' + type : ''}`;
}

function renderJsonDiff(parts) {
  jsonDiffOutput.textContent = '';
  parts.forEach((part) => {
    const cls = part.added ? 'diff-line diff-line-added' : part.removed ? 'diff-line diff-line-removed' : 'diff-line';
    const text = part.value.endsWith('\n') ? part.value.slice(0, -1) : part.value;
    text.split('\n').forEach((line) => {
      const div = document.createElement('div');
      div.className = cls;
      div.textContent = line;
      jsonDiffOutput.appendChild(div);
    });
  });
}

function compareJsonDiff() {
  const leftText = jsonDiffInputLeft.value;
  const rightText = jsonDiffInputRight.value;

  if (!leftText.trim() || !rightText.trim()) {
    jsonDiffOutput.textContent = 'Paste JSON on both sides and click "Compare JSON" to see the differences.';
    setJsonDiffStatus('', '');
    return;
  }

  let leftObj;
  let rightObj;
  try {
    leftObj = JSON.parse(leftText);
  } catch (e) {
    jsonDiffOutput.textContent = '';
    setJsonDiffStatus(`✗ Original JSON is invalid — ${e.message}`, 'error');
    return;
  }
  try {
    rightObj = JSON.parse(rightText);
  } catch (e) {
    jsonDiffOutput.textContent = '';
    setJsonDiffStatus(`✗ Changed JSON is invalid — ${e.message}`, 'error');
    return;
  }

  const parts = Diff.diffJson(leftObj, rightObj);
  const hasChanges = parts.some((p) => p.added || p.removed);
  setJsonDiffStatus(
    hasChanges ? '● Differences found' : '✓ JSON documents are equivalent',
    hasChanges ? 'info' : 'success'
  );
  renderJsonDiff(parts);
}

jsonDiffCompareBtn.addEventListener('click', compareJsonDiff);

jsonDiffSampleLeftBtn.addEventListener('click', () => { jsonDiffInputLeft.value = JSON_DIFF_SAMPLE_LEFT; });
jsonDiffSampleRightBtn.addEventListener('click', () => { jsonDiffInputRight.value = JSON_DIFF_SAMPLE_RIGHT; });

jsonDiffClearLeftBtn.addEventListener('click', () => { jsonDiffInputLeft.value = ''; });
jsonDiffClearRightBtn.addEventListener('click', () => { jsonDiffInputRight.value = ''; });
