// ---- Base64 image converter ----
const b64Input = document.getElementById('b64Input');
const b64Preview = document.getElementById('b64Preview');
const b64Status = document.getElementById('b64Status');
const b64Info = document.getElementById('b64Info');
const b64DownloadBtn = document.getElementById('b64Download');
const b64Decode = document.getElementById('b64Decode');
const b64Encode = document.getElementById('b64Encode');
const b64ModeDecode = document.getElementById('b64ModeDecode');
const b64ModeEncode = document.getElementById('b64ModeEncode');

// 1x1 purple PNG
const B64_SAMPLE = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPj/HwADBwIAMCbHYQAAAABJRU5ErkJggg==';

let b64DecodedUrl = null;
let b64DecodedExt = 'png';

function setB64Mode(mode) {
  const decode = mode === 'decode';
  b64Decode.style.display = decode ? '' : 'none';
  b64Encode.style.display = decode ? 'none' : '';
  b64ModeDecode.classList.toggle('active', decode);
  b64ModeEncode.classList.toggle('active', !decode);
}
b64ModeDecode.addEventListener('click', () => setB64Mode('decode'));
b64ModeEncode.addEventListener('click', () => setB64Mode('encode'));

function setB64Status(msg, type) {
  b64Status.textContent = msg;
  b64Status.className = `json-status${type ? ' ' + type : ''}`;
}

function sniffImageType(bytes) {
  const hex = Array.from(bytes.slice(0, 12), (b) => b.toString(16).padStart(2, '0')).join('');
  if (hex.startsWith('89504e47')) return { mime: 'image/png', ext: 'png' };
  if (hex.startsWith('ffd8ff')) return { mime: 'image/jpeg', ext: 'jpg' };
  if (hex.startsWith('47494638')) return { mime: 'image/gif', ext: 'gif' };
  if (hex.startsWith('52494646') && hex.slice(16, 24) === '57454250') return { mime: 'image/webp', ext: 'webp' };
  if (hex.startsWith('424d')) return { mime: 'image/bmp', ext: 'bmp' };
  if (hex.startsWith('00000100')) return { mime: 'image/x-icon', ext: 'ico' };
  const text = new TextDecoder().decode(bytes.slice(0, 200)).trimStart().toLowerCase();
  if (text.startsWith('<svg') || text.startsWith('<?xml')) return { mime: 'image/svg+xml', ext: 'svg' };
  return null;
}

function decodeBase64Image() {
  let raw = b64Input.value.trim();
  b64DownloadBtn.disabled = true;
  b64Info.textContent = '';
  if (!raw) {
    setB64Status('', '');
    b64Preview.textContent = 'Decoded image appears here.';
    return;
  }
  raw = raw.replace(/^data:[^,]*,/i, '').replace(/\s+/g, '').replace(/-/g, '+').replace(/_/g, '/');
  let bytes;
  try {
    const bin = atob(raw);
    bytes = Uint8Array.from(bin, (c) => c.charCodeAt(0));
  } catch (e) {
    b64Preview.textContent = 'Decoded image appears here.';
    setB64Status('✗ Invalid Base64 string', 'error');
    return;
  }
  const type = sniffImageType(bytes);
  if (!type) {
    b64Preview.textContent = 'Decoded image appears here.';
    setB64Status('✗ Decoded data is not a recognized image', 'error');
    return;
  }
  if (b64DecodedUrl) URL.revokeObjectURL(b64DecodedUrl);
  b64DecodedUrl = URL.createObjectURL(new Blob([bytes], { type: type.mime }));
  b64DecodedExt = type.ext;

  const img = new Image();
  img.alt = 'Decoded image';
  img.onload = () => {
    b64Info.textContent = `${type.mime} · ${img.naturalWidth}×${img.naturalHeight}px · ${(bytes.length / 1024).toFixed(1)} KB`;
  };
  img.src = b64DecodedUrl;
  b64Preview.textContent = '';
  b64Preview.appendChild(img);
  b64DownloadBtn.disabled = false;
  setB64Status('✓ Image decoded', 'success');
}

document.getElementById('b64DecodeBtn').addEventListener('click', decodeBase64Image);
document.getElementById('b64Sample').addEventListener('click', () => {
  b64Input.value = B64_SAMPLE;
  decodeBase64Image();
});
document.getElementById('b64Clear').addEventListener('click', () => {
  b64Input.value = '';
  decodeBase64Image();
  b64Input.focus();
});
b64DownloadBtn.addEventListener('click', () => {
  if (!b64DecodedUrl) return;
  const a = document.createElement('a');
  a.href = b64DecodedUrl;
  a.download = `image.${b64DecodedExt}`;
  a.click();
});

// Encode: image -> Base64
const b64Output = document.getElementById('b64Output');
const b64EncPreview = document.getElementById('b64EncPreview');
let b64DataUri = '';

document.getElementById('b64File').addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (ev) => {
    b64DataUri = ev.target.result;
    b64Output.value = b64DataUri.slice(b64DataUri.indexOf(',') + 1);
    const img = new Image();
    img.alt = 'Selected image';
    img.src = b64DataUri;
    b64EncPreview.textContent = '';
    b64EncPreview.appendChild(img);
  };
  reader.readAsDataURL(file);
});

const b64CopyRaw = document.getElementById('b64CopyRaw');
const b64CopyUri = document.getElementById('b64CopyUri');
b64CopyRaw.addEventListener('click', () => copyWithLabel(b64CopyRaw, b64Output.value));
b64CopyUri.addEventListener('click', () => copyWithLabel(b64CopyUri, b64DataUri));
