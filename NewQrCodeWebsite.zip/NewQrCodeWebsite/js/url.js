// ---- URL encoder / decoder ----
const urlInput = document.getElementById('urlInput');
const urlOutput = document.getElementById('urlOutput');
const urlStatus = document.getElementById('urlStatus');
const urlPlus = document.getElementById('urlPlus');
const urlFull = document.getElementById('urlFull');
const urlRunBtn = document.getElementById('urlRun');
const urlCopyBtn = document.getElementById('urlCopy');
const URL_SAMPLES = {
  decode: 'https%3A%2F%2Fexample.com%2Fsearch%3Fq%3Dhello+world%26lang%3Den%26name%3DJos%C3%A9',
  encode: 'https://example.com/search?q=hello world&lang=en&name=José',
};
let urlMode = 'decode';

function setUrlMode(mode) {
  urlMode = mode;
  const decode = mode === 'decode';
  document.getElementById('urlModeDecode').classList.toggle('active', decode);
  document.getElementById('urlModeEncode').classList.toggle('active', !decode);
  document.getElementById('urlInputLabel').textContent = decode ? 'Text to decode' : 'Text to encode';
  document.getElementById('urlOutputLabel').textContent = decode ? 'Decoded output' : 'Encoded output';
  document.getElementById('urlPlusWrap').style.display = decode ? '' : 'none';
  document.getElementById('urlFullWrap').style.display = decode ? 'none' : '';
  urlInput.placeholder = decode ? 'Type or paste the URL-encoded text here...' : 'Type or paste the text to encode here...';
  urlRunBtn.textContent = decode ? 'Decode' : 'Encode';
  runUrlTool();
}

function runUrlTool() {
  const text = urlInput.value;
  urlStatus.textContent = '';
  urlStatus.className = 'json-status';
  if (!text) { urlOutput.value = ''; return; }
  try {
    if (urlMode === 'decode') {
      const src = urlPlus.checked ? text.replace(/\+/g, ' ') : text;
      urlOutput.value = decodeURIComponent(src);
      urlStatus.textContent = '✓ Decoded';
    } else {
      urlOutput.value = urlFull.checked ? encodeURI(text) : encodeURIComponent(text);
      urlStatus.textContent = '✓ Encoded';
    }
    urlStatus.className = 'json-status success';
  } catch (e) {
    urlOutput.value = '';
    urlStatus.textContent = '✗ Invalid URL-encoded input (malformed % sequence)';
    urlStatus.className = 'json-status error';
  }
}

document.getElementById('urlModeDecode').addEventListener('click', () => setUrlMode('decode'));
document.getElementById('urlModeEncode').addEventListener('click', () => setUrlMode('encode'));
urlRunBtn.addEventListener('click', runUrlTool);
urlInput.addEventListener('input', runUrlTool);
urlPlus.addEventListener('change', runUrlTool);
urlFull.addEventListener('change', runUrlTool);
document.getElementById('urlSample').addEventListener('click', () => {
  urlInput.value = URL_SAMPLES[urlMode];
  runUrlTool();
});
document.getElementById('urlClear').addEventListener('click', () => {
  urlInput.value = '';
  runUrlTool();
  urlInput.focus();
});
document.getElementById('urlSwap').addEventListener('click', () => {
  if (!urlOutput.value) return;
  urlInput.value = urlOutput.value;
  setUrlMode(urlMode === 'decode' ? 'encode' : 'decode');
});
urlCopyBtn.addEventListener('click', () => copyWithLabel(urlCopyBtn, urlOutput.value));


