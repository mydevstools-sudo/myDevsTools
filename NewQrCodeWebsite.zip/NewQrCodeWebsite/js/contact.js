document.getElementById('contactForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const name = document.getElementById('cName').value.trim();
  const email = document.getElementById('cEmail').value.trim();
  const msg = document.getElementById('cMsg').value.trim();
  const body = `${msg}\n\n— ${name} (${email})`;
  window.location.href = 'mailto:myDevsTools@gmail.com?subject=' + encodeURIComponent('myDevTools contact from ' + name) +
    '&body=' + encodeURIComponent(body);
});
