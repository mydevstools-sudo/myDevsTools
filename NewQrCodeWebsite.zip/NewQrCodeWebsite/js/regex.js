(function () {
  const $ = (id) => document.getElementById(id);
  const copyText = (text) => navigator.clipboard.writeText(text);
  const download = (href, name) => { const a = document.createElement('a'); a.href = href; a.download = name; a.click(); };
  // Regex
  const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  function runRegex() {
    const st = $('rxStatus'), text = $('rxText').value, pat = $('rxPattern').value;
    $('rxHighlight').innerHTML = esc(text); $('rxList').textContent = '';
    if (!pat) { st.textContent = ''; st.className = 'json-status'; return; }
    try {
      let flags = $('rxFlags').value;
      if (!flags.includes('g')) flags += 'g';
      const re = new RegExp(pat, flags);
      let html = '', last = 0, n = 0, list = [], m;
      while ((m = re.exec(text)) !== null && n < 1000) {
        html += esc(text.slice(last, m.index)) + '<mark class="rx-hit">' + esc(m[0]) + '</mark>';
        last = m.index + m[0].length;
        n++;
        list.push('#' + n + ' @' + m.index + ': ' + JSON.stringify(m[0]) + (m.length > 1 ? '  groups: ' + JSON.stringify(m.slice(1)) : ''));
        if (m[0] === '') re.lastIndex++;
      }
      $('rxHighlight').innerHTML = html + esc(text.slice(last));
      $('rxList').textContent = list.join('\n');
      st.textContent = n + (n === 1 ? ' match' : ' matches'); st.className = 'json-status ' + (n ? 'success' : '');
    } catch (e) {
      st.textContent = e.message; st.className = 'json-status error';
    }
  }
  ['rxPattern', 'rxFlags', 'rxText'].forEach((id) => $(id).addEventListener('input', runRegex));
})();
