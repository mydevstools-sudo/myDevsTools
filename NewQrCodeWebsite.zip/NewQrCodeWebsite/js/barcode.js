(function () {
  const $ = (id) => document.getElementById(id);
  const copyText = (text) => navigator.clipboard.writeText(text);
  const download = (href, name) => { const a = document.createElement('a'); a.href = href; a.download = name; a.click(); };
  // Barcode
  function drawBarcode() {
    const st = $('bcStatus');
    try {
      JsBarcode('#bcSvgEl', $('bcValue').value, { format: $('bcFormat').value, lineColor: '#1a1a2e', width: 2, height: 100, displayValue: true });
      st.textContent = ''; st.className = 'json-status';
    } catch (e) {
      $('bcSvgEl').innerHTML = '';
      st.textContent = 'Invalid value for this format.'; st.className = 'json-status error';
    }
  }
  $('bcValue').addEventListener('input', drawBarcode);
  $('bcFormat').addEventListener('change', drawBarcode);
  $('bcSvg').addEventListener('click', () => {
    const xml = new XMLSerializer().serializeToString($('bcSvgEl'));
    download('data:image/svg+xml;charset=utf-8,' + encodeURIComponent(xml), 'barcode.svg');
  });
  $('bcPng').addEventListener('click', () => {
    const svg = $('bcSvgEl');
    const xml = new XMLSerializer().serializeToString(svg);
    const img = new Image();
    img.onload = () => {
      const c = document.createElement('canvas');
      c.width = img.width * 2; c.height = img.height * 2;
      const ctx = c.getContext('2d');
      ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height);
      ctx.drawImage(img, 0, 0, c.width, c.height);
      download(c.toDataURL('image/png'), 'barcode.png');
    };
    img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(xml);
  });
  window.toolInit.barcode = drawBarcode;
  if (window.toolInit.barcode) window.toolInit.barcode();
})();
