(function () {
  const $ = (id) => document.getElementById(id);
  const copyText = (text) => navigator.clipboard.writeText(text);
  const download = (href, name) => { const a = document.createElement('a'); a.href = href; a.download = name; a.click(); };
  // Word counter
  function countWords() {
    const t = $('wcInput').value;
    const words = (t.match(/\S+/g) || []).length;
    $('wcWords').textContent = words;
    $('wcChars').textContent = t.length;
    $('wcCharsNs').textContent = t.replace(/\s/g, '').length;
    $('wcSentences').textContent = (t.match(/[^.!?]+[.!?]+|[^.!?]+$/g) || []).filter((s) => s.trim()).length;
    $('wcParas').textContent = t.split(/\n\s*\n/).filter((p) => p.trim()).length;
    $('wcRead').textContent = words ? Math.max(1, Math.ceil(words / 200)) + ' min' : '0 min';
  }
  $('wcInput').addEventListener('input', countWords);
  $('wcClear').addEventListener('click', () => { $('wcInput').value = ''; countWords(); });
})();
