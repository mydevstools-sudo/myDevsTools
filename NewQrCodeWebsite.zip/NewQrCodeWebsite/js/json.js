// ---- JSON Parser ----
const jsonInput = document.getElementById('jsonInput');
const jsonOutput = document.getElementById('jsonOutput');
const jsonStatus = document.getElementById('jsonStatus');
const jsonSampleBtn = document.getElementById('jsonSample');
const jsonClearBtn = document.getElementById('jsonClear');
const jsonCopyBtn = document.getElementById('jsonCopy');
const jsonValidateBtn = document.getElementById('jsonValidate');

const JSON_SAMPLE = `{
  "name": "Jane Doe",
  "age": 29,
  "isActive": true,
  "skills": ["JavaScript", "Python", "SQL"],
  "address": {
    "city": "San Francisco",
    "zip": "94107"
  }
}`;

function getLineColumn(text, pos) {
  const upToPos = text.slice(0, pos);
  const lines = upToPos.split('\n');
  return { line: lines.length, column: lines[lines.length - 1].length + 1 };
}

function setJsonStatus(message, type) {
  jsonStatus.textContent = message;
  jsonStatus.className = `json-status${type ? ' ' + type : ''}`;
}

function validateJson() {
  const text = jsonInput.value;
  if (!text.trim()) {
    setJsonStatus('', '');
    jsonOutput.textContent = '';
    return;
  }
  try {
    const parsed = JSON.parse(text);
    jsonOutput.textContent = JSON.stringify(parsed, null, 2);
    setJsonStatus('✓ Valid JSON', 'success');
  } catch (e) {
    let detail = e.message;
    const match = detail.match(/position (\d+)/);
    if (match) {
      const { line, column } = getLineColumn(text, parseInt(match[1], 10));
      detail = `${e.message} (line ${line}, column ${column})`;
    }
    jsonOutput.textContent = '';
    setJsonStatus(`✗ Invalid JSON — ${detail}`, 'error');
  }
}

let jsonTimer = null;
jsonInput.addEventListener('input', () => {
  clearTimeout(jsonTimer);
  jsonTimer = setTimeout(validateJson, 250);
});

jsonValidateBtn.addEventListener('click', validateJson);

jsonSampleBtn.addEventListener('click', () => {
  jsonInput.value = JSON_SAMPLE;
  validateJson();
});

jsonClearBtn.addEventListener('click', () => {
  jsonInput.value = '';
  jsonOutput.textContent = '';
  setJsonStatus('', '');
  jsonInput.focus();
});

jsonCopyBtn.addEventListener('click', () => {
  if (!jsonOutput.textContent) return;
  navigator.clipboard.writeText(jsonOutput.textContent).then(() => {
    const original = jsonCopyBtn.textContent;
    jsonCopyBtn.textContent = 'Copied!';
    setTimeout(() => { jsonCopyBtn.textContent = original; }, 1500);
  });
});

