(function () {
  const $ = (id) => document.getElementById(id);
  const copyText = (text) => navigator.clipboard.writeText(text);
  const download = (href, name) => { const a = document.createElement('a'); a.href = href; a.download = name; a.click(); };
  // UUID
  function genUuids() {
    const n = Math.min(500, Math.max(1, parseInt($('uuidCount').value, 10) || 1));
    const out = [];
    for (let i = 0; i < n; i++) {
      let u = crypto.randomUUID();
      if ($('uuidUpper').checked) u = u.toUpperCase();
      if ($('uuidNoDash').checked) u = u.replace(/-/g, '');
      out.push(u);
    }
    $('uuidOutput').value = out.join('\n');
  }
  $('uuidGen').addEventListener('click', genUuids);
  $('uuidCopy').addEventListener('click', () => copyText($('uuidOutput').value));
  window.toolInit.uuid = () => { if (!$('uuidOutput').value) genUuids(); };
  if (window.toolInit.uuid) window.toolInit.uuid();
})();
