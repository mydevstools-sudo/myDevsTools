// ---- JSON Diff ----
const jsonDiffInputLeft = document.getElementById('jsonDiffInputLeft');
const jsonDiffInputRight = document.getElementById('jsonDiffInputRight');
const jsonDiffOutput = document.getElementById('jsonDiffOutput');
const jsonDiffStatus = document.getElementById('jsonDiffStatus');
const jsonDiffCompareBtn = document.getElementById('jsonDiffCompareBtn');
const jsonDiffSampleLeftBtn = document.getElementById('jsonDiffSampleLeft');
const jsonDiffSampleRightBtn = document.getElementById('jsonDiffSampleRight');
const jsonDiffClearLeftBtn = document.getElementById('jsonDiffClearLeft');
const jsonDiffClearRightBtn = document.getElementById('jsonDiffClearRight');

const JSON_DIFF_SAMPLE_LEFT = `{
  "name": "Jane Doe",
  "age": 29,
  "city": "San Francisco",
  "skills": ["JavaScript", "Python"]
}`;
const JSON_DIFF_SAMPLE_RIGHT = `{
  "name": "Jane Doe",
  "age": 30,
  "country": "USA",
  "skills": ["JavaScript", "Python", "Go"]
}`;

function setJsonDiffStatus(message, type) {
  jsonDiffStatus.textContent = message;
  jsonDiffStatus.className = `json-status${type ? ' ' + type : ''}`;
}

function renderJsonDiff(parts) {
  jsonDiffOutput.textContent = '';
  parts.forEach((part) => {
    const cls = part.added ? 'diff-line diff-line-added' : part.removed ? 'diff-line diff-line-removed' : 'diff-line';
    const text = part.value.endsWith('\n') ? part.value.slice(0, -1) : part.value;
    text.split('\n').forEach((line) => {
      const div = document.createElement('div');
      div.className = cls;
      div.textContent = line;
      jsonDiffOutput.appendChild(div);
    });
  });
}

function compareJsonDiff() {
  const leftText = jsonDiffInputLeft.value;
  const rightText = jsonDiffInputRight.value;

  if (!leftText.trim() || !rightText.trim()) {
    jsonDiffOutput.textContent = 'Paste JSON on both sides and click "Compare JSON" to see the differences.';
    setJsonDiffStatus('', '');
    return;
  }

  let leftObj;
  let rightObj;
  try {
    leftObj = JSON.parse(leftText);
  } catch (e) {
    jsonDiffOutput.textContent = '';
    setJsonDiffStatus(`✗ Original JSON is invalid — ${e.message}`, 'error');
    return;
  }
  try {
    rightObj = JSON.parse(rightText);
  } catch (e) {
    jsonDiffOutput.textContent = '';
    setJsonDiffStatus(`✗ Changed JSON is invalid — ${e.message}`, 'error');
    return;
  }

  const parts = Diff.diffJson(leftObj, rightObj);
  const hasChanges = parts.some((p) => p.added || p.removed);
  setJsonDiffStatus(
    hasChanges ? '● Differences found' : '✓ JSON documents are equivalent',
    hasChanges ? 'info' : 'success'
  );
  renderJsonDiff(parts);
}

jsonDiffCompareBtn.addEventListener('click', compareJsonDiff);

jsonDiffSampleLeftBtn.addEventListener('click', () => { jsonDiffInputLeft.value = JSON_DIFF_SAMPLE_LEFT; });
jsonDiffSampleRightBtn.addEventListener('click', () => { jsonDiffInputRight.value = JSON_DIFF_SAMPLE_RIGHT; });

jsonDiffClearLeftBtn.addEventListener('click', () => { jsonDiffInputLeft.value = ''; });
jsonDiffClearRightBtn.addEventListener('click', () => { jsonDiffInputRight.value = ''; });

