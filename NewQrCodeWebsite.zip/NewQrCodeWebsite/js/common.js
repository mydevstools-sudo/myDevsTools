window.toolInit = window.toolInit || {};
document.getElementById('year').textContent = new Date().getFullYear();

// ---- Mobile menu ----
const menuToggle = document.getElementById('menuToggle');
const mainNav = document.getElementById('mainNav');
const siteHeader = document.querySelector('.site-header');

function setMenu(open) {
  siteHeader.classList.toggle('menu-open', open);
  menuToggle.setAttribute('aria-expanded', String(open));
}

menuToggle.addEventListener('click', () => {
  setMenu(!siteHeader.classList.contains('menu-open'));
});

function copyWithLabel(btn, text) {
  if (!text) return;
  const original = btn.textContent;
  navigator.clipboard.writeText(text).then(() => {
    btn.textContent = 'Copied!';
    setTimeout(() => { btn.textContent = original; }, 1500);
  });
}
