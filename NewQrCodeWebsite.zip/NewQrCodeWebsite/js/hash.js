(function () {
  const $ = (id) => document.getElementById(id);
  const copyText = (text) => navigator.clipboard.writeText(text);
  const download = (href, name) => { const a = document.createElement('a'); a.href = href; a.download = name; a.click(); };
  // Hash
  async function runHash() {
    const data = new TextEncoder().encode($('hashInput').value);
    for (const [id, alg] of [['hashSha1', 'SHA-1'], ['hashSha256', 'SHA-256'], ['hashSha384', 'SHA-384'], ['hashSha512', 'SHA-512']]) {
      const buf = await crypto.subtle.digest(alg, data);
      $(id).value = Array.from(new Uint8Array(buf), (b) => b.toString(16).padStart(2, '0')).join('');
    }
  }
  $('hashInput').addEventListener('input', runHash);
  document.querySelectorAll('[data-copy]').forEach((b) => b.addEventListener('click', () => copyText($(b.dataset.copy).value)));
  window.toolInit.hash = runHash;
  if (window.toolInit.hash) window.toolInit.hash();
})();
