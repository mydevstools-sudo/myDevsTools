let currentType = 'url';
let logoDataUrl = null;

const qrCode = new QRCodeStyling({
  width: 260,
  height: 260,
  type: 'svg',
  data: 'https://example.com',
  margin: 8,
  qrOptions: { errorCorrectionLevel: 'H' },
  dotsOptions: { color: '#1a1a2e', type: 'classy' },
  backgroundOptions: { color: '#ffffff' },
  cornersSquareOptions: { color: '#1a1a2e', type: 'extra-rounded' },
  cornersDotOptions: { color: '#1a1a2e' },
  imageOptions: { crossOrigin: 'anonymous', margin: 6, imageSize: 0.3 },
});

qrCode.append(document.getElementById('qrPreview'));

const heroQr = new QRCodeStyling({
  width: 220,
  height: 220,
  type: 'svg',
  data: 'https://example.com',
  margin: 6,
  qrOptions: { errorCorrectionLevel: 'Q' },
  dotsOptions: { color: '#1a1a2e', type: 'classy' },
  backgroundOptions: { color: '#ffffff' },
  cornersSquareOptions: { color: '#1a1a2e', type: 'extra-rounded' },
  cornersDotOptions: { color: '#1a1a2e' },
});
heroQr.append(document.getElementById('heroQrFrame'));

// ---- Type tabs ----
const typeTabs = document.querySelectorAll('.type-tab');
const typeForms = document.querySelectorAll('.type-form');

typeTabs.forEach((tab) => {
  tab.addEventListener('click', () => {
    typeTabs.forEach((t) => t.classList.remove('active'));
    tab.classList.add('active');
    currentType = tab.dataset.type;
    typeForms.forEach((f) => f.classList.toggle('active', f.dataset.form === currentType));
    updateQrData();
  });
});

// ---- Data builders ----
function escapeVCard(str) {
  return (str || '').replace(/([,;])/g, '\\$1');
}

function buildData() {
  switch (currentType) {
    case 'url': {
      let val = document.getElementById('url-input').value.trim() || 'https://example.com';
      if (!/^https?:\/\//i.test(val)) val = 'https://' + val;
      return val;
    }
    case 'text':
      return document.getElementById('text-input').value || ' ';
    case 'email': {
      const addr = document.getElementById('email-address').value.trim();
      const subject = encodeURIComponent(document.getElementById('email-subject').value.trim());
      const body = encodeURIComponent(document.getElementById('email-body').value.trim());
      let str = `mailto:${addr}`;
      const params = [];
      if (subject) params.push(`subject=${subject}`);
      if (body) params.push(`body=${body}`);
      if (params.length) str += `?${params.join('&')}`;
      return str;
    }
    case 'phone': {
      const num = document.getElementById('phone-input').value.trim();
      return `tel:${num}`;
    }
    case 'sms': {
      const num = document.getElementById('sms-number').value.trim();
      const msg = encodeURIComponent(document.getElementById('sms-message').value.trim());
      return msg ? `smsto:${num}:${msg}` : `smsto:${num}:`;
    }
    case 'wifi': {
      const ssid = escapeVCard(document.getElementById('wifi-ssid').value.trim());
      const pass = escapeVCard(document.getElementById('wifi-password').value.trim());
      const enc = document.getElementById('wifi-encryption').value;
      const hidden = document.getElementById('wifi-hidden').checked ? 'true' : 'false';
      const passSegment = enc === 'nopass' ? '' : `P:${pass};`;
      return `WIFI:T:${enc};S:${ssid};${passSegment}H:${hidden};;`;
    }
    case 'vcard': {
      const first = document.getElementById('vcard-first').value.trim();
      const last = document.getElementById('vcard-last').value.trim();
      const phone = document.getElementById('vcard-phone').value.trim();
      const email = document.getElementById('vcard-email').value.trim();
      const company = document.getElementById('vcard-company').value.trim();
      const website = document.getElementById('vcard-website').value.trim();
      return [
        'BEGIN:VCARD',
        'VERSION:3.0',
        `N:${escapeVCard(last)};${escapeVCard(first)};;;`,
        `FN:${escapeVCard(first + ' ' + last)}`,
        company ? `ORG:${escapeVCard(company)}` : '',
        phone ? `TEL;TYPE=CELL:${phone}` : '',
        email ? `EMAIL:${email}` : '',
        website ? `URL:${website}` : '',
        'END:VCARD',
      ].filter(Boolean).join('\n');
    }
    default:
      return ' ';
  }
}

// ---- Update QR ----
let updateTimer = null;
function updateQrData() {
  clearTimeout(updateTimer);
  updateTimer = setTimeout(() => {
    const data = buildData() || ' ';
    qrCode.update({ data });
  }, 150);
}

function updateQrStyle() {
  const fg = document.getElementById('fgColor').value;
  const bg = document.getElementById('bgColor').value;
  const dotStyle = document.getElementById('dotStyle').value;
  const cornerStyle = document.getElementById('cornerStyle').value;

  qrCode.update({
    dotsOptions: { color: fg, type: dotStyle },
    backgroundOptions: { color: bg },
    cornersSquareOptions: { color: fg, type: cornerStyle },
    cornersDotOptions: { color: fg },
    image: logoDataUrl || undefined,
  });
}

// ---- Listen to all inputs ----
document.querySelectorAll('.type-form input, .type-form textarea, .type-form select')
  .forEach((el) => el.addEventListener('input', updateQrData));

['fgColor', 'bgColor', 'dotStyle', 'cornerStyle'].forEach((id) => {
  document.getElementById(id).addEventListener('input', updateQrStyle);
  document.getElementById(id).addEventListener('change', updateQrStyle);
});

// ---- Logo upload ----
document.getElementById('logoUpload').addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (ev) => {
    logoDataUrl = ev.target.result;
    updateQrStyle();
  };
  reader.readAsDataURL(file);
});

document.getElementById('removeLogo').addEventListener('click', () => {
  logoDataUrl = null;
  document.getElementById('logoUpload').value = '';
  updateQrStyle();
});

// ---- Downloads ----
document.getElementById('downloadPng').addEventListener('click', () => {
  qrCode.download({ name: 'qr-code', extension: 'png' });
});
document.getElementById('downloadSvg').addEventListener('click', () => {
  qrCode.download({ name: 'qr-code', extension: 'svg' });
});
document.getElementById('downloadJpg').addEventListener('click', () => {
  qrCode.download({ name: 'qr-code', extension: 'jpeg' });
});

// ---- Init ----
updateQrData();
